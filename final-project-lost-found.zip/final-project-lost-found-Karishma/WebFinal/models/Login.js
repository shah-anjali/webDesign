// Here we are defining the mongoose settings 
var mongoose = require('mongoose');
// Here we are defining the schema of the mongoose
var LoginSchema = new mongoose.Schema({
    username: String,
    email: String,
    password: String,

});
// We have used mongoose for the login page
module.exports = mongoose.model('Login', LoginSchema);