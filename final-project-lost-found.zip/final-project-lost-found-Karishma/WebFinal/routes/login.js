var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var Login = require('../models/Login.js');

/* GET ALL users */
router.get('/', function(req, res, next) {
  Login.find(function (err, products) {
    if (err) return next(err);
    res.json(products);
  });
});

/* GET SINGLE user BY ID */
router.get('/:id', function(req, res, next) {
    Login.findById(req.params.id, function (err, post) {
    if (err) return next(err);
    res.json(post);
  });
});

/* SAVE user */
router.post('/', function(req, res, next) {
    Login.create(req.body, function (err, post) {
    if (err) return next(err);
    res.json(post);
  });
});

/* UPDATE user */
router.put('/register', function(req, res, next) {
  Login.findByIdAndUpdate(req.params.id, req.body, function (err, post) {
    if (err) return next(err);
    res.json(post);
  });
});

/* DELETE user */
router.delete('/:id', function(req, res, next) {
  Login.findByIdAndRemove(req.params.id, req.body, function (err, post) {
    if (err) return next(err);
    res.json(post);
  });
});

module.exports = router;
