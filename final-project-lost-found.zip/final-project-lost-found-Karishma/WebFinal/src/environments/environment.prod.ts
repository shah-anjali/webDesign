export const environment = {
  production: true,
  api_url: 'https://conduit.productionready.io/api',
  PIXABAY_API_KEY: '8796069-7fe94f3fe44b7040802741cae',
  PIXABAY_API_URL: "https://pixabay.com/api/?key=",
  // "https://pixabay.com/api/videos/?key=",
};
