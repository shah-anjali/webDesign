import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchComponent } from './search.component';

import { AuthGuard } from '../core';
import { SharedModule } from '../shared';
//This module managing routing for the editor
const routes: Routes = [
  {
    path: '',
    component: SearchComponent,
    canActivate: [AuthGuard]
  },
  {
    // path: ':slug',
    // component: SearchComponent,
    // canActivate: [AuthGuard],
    // resolve: {
    //   article: EditableArticleResolver
    // }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EditorRoutingModule {}
