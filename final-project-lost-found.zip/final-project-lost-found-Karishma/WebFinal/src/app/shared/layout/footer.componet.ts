import { Component } from '@angular/core';

@Component({
  selector: 'app-layout-footer',
  templateUrl: './footer.component.html'
})
export class FooterComponent {
    // we are using datepipe to get the current date/year in the footer//
  today: number = Date.now();
}
