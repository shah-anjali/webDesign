import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { ArticleListConfig, TagsService, UserService } from '../core';
//var Request = require("request");


@Component({
  selector: 'app-home-page',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  constructor(
    private router: Router,
    private tagsServices: TagsService,
    private userService: UserService
    
  ) {}

  isAuthenticated: boolean;
  listConfig: ArticleListConfig = {
    type: 'all',
    filters: {}
  };
  tags: Array<string> = [];
  tagsLoaded = false;

  ngOnInit() {
    this.userService.isAuthenticated.subscribe(
      (authenticated) => {
        this.isAuthenticated = authenticated;

        // set the article list accordingly
        if (authenticated) {
          this.setListTo('feed');
        } else {
          this.setListTo('all');
        }
      }
    );

    this.tagsServices.getAll()
    .subscribe(tags => {
      this.tags = tags;
      this.tagsLoaded = true;
    });
  }

  setListTo(type: string = '', filters: Object = {}) {
    // If feed is requested but user is not authenticated, redirect to login
    if (type === 'feed' && !this.isAuthenticated) {
      this.router.navigateByUrl('/login');
      return;
    }

    // Otherwise, set the list object
    this.listConfig = {type: type, filters: filters};
  }

 /* book = [];
  
    onClickMe() {
    
 Request.get("https://putsreq.com/YwiX9Kk0BMEkon32HrPk", (error, response, body) => {
    if(error) {
    
        //return console.dir(error);
    }
    this.book =JSON.parse(body);
    var b = this.book.length;
    var htmlContent='';
    debugger;
    //var searchBookName = document.getElementById("SearchBookValue");
   // alert(searchBookName);
    for(var i=0;i<b; i++){
     // if(this.book.indexOf(searchBookName)> -1)
    htmlContent=htmlContent+"<br/>Book Name :"+this.book[i].BookName+"<br /> Price : "+this.book[i].Price+"<br/>Author : "+this.book[i].Author+"<br/>";
    }
    document.getElementById("booklist").innerHTML = htmlContent;
    
    
    //console.dir(JSON.parse(body));
});
    }*/
}

