
Build the file:
To start the code 
npm install

`
To run the application
ng serve 

Knowledge Hub Portal


This Application is basically used to share your knowledge among others.
-For this we have used MongoDB Database for creating the users and API for fetching the feeds of the users.

-First step is the Sign Up where the user is registered and its details like ‘Username’, ‘Email’ and ‘Password’ are stored in the database.

-Secondly, the user created can then Login to his/her Profile and share knowledge of whichever topic that he wishes to.
He can perform CREATE, READ, EDIT and DELETE operations on the feeds created by him.

-He/She can also view the feeds shared by others.-He can also perform the SEARCH operation on the type of feeds or knowledge that he wishes to learn about.

-He can also view the DETAILED view of the feed by clicking on Read More.-He can mark the article as his Favorite Article by clicking on the Like icon and can follow the person that created such a Feed so that he would be able to see all the feeds that this person shares. 

The application has few ng-module external dependencies.
Uer requires to add files in ng-module after npm install. Files to be included are:-
1. ng module->@angular should have (http, material and cdk) files  
2. ng module->angular2-masonry.
